#include <stdint.h>

void
flatten_ll(uint32_t *ll_hist);
